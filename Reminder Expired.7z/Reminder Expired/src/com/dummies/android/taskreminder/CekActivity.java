package com.dummies.android.taskreminder;

import com.anggoro.android.expiredreminder.R;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class CekActivity extends Activity {
	static final String ACTION_SCAN = "com.google.zxing.client.android.SCAN";
	private EditText hasilTxt;

	private DbAdapter mDbHelper;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reminder_cek);

		hasilTxt = (EditText) findViewById(R.id.hasil);

		mDbHelper = new DbAdapter(this);
	}

	public void scanBar(View v) {
		try {
			Intent intent = new Intent(ACTION_SCAN);
			intent.putExtra("SCAN_MODE", "PRODUCT_MODE");
			startActivityForResult(intent, 0);
		} catch (ActivityNotFoundException anfe) {
			showDialog(CekActivity.this, "Aplikasi scanner belum ada", "Bersedia download aplikasi?", "Ya", "Tidak").show();
		}

		IntentIntegrator scanIntegrator = new IntentIntegrator(this);
		scanIntegrator.initiateScan();
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		IntentResult scanningResult = IntentIntegrator.parseActivityResult( requestCode, resultCode, intent);

		if (scanningResult != null) {
			String scanContent = scanningResult.getContents();
			String scanFormat = scanningResult.getFormatName();

			mDbHelper.open();
			Cursor c = mDbHelper.select(scanFormat + scanContent);

			if (c.getCount() != 0) {
				c.moveToFirst();

				int id = c.getInt(0);
				String nama = c.getString(1);
				String kode = c.getString(2);
				String tanggal = c.getString(3);
				
				hasilTxt.setText("Produk " + nama + ", kadaluarsa pada tanggal " + tanggal);
			}
			else {
				Toast.makeText(this, "Data kosong, belum ada di database!", Toast.LENGTH_SHORT).show();
			}
			
		}
	}

	private static AlertDialog showDialog(final Activity act,CharSequence title, CharSequence message, CharSequence buttonYes, CharSequence buttonNo) {

		AlertDialog.Builder downloadDialog = new AlertDialog.Builder(act);
		downloadDialog.setTitle(title);
		downloadDialog.setMessage(message);
		downloadDialog.setPositiveButton(buttonYes, new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialogInterface, int i) {
				Uri uri = Uri.parse("market://search?q=pname:" + "com.google.zxing.client.android");
	
				Intent intent = new Intent(Intent.ACTION_VIEW, uri);
					try {
						act.startActivity(intent);
					} catch 
					(ActivityNotFoundException anfe) {
					}
			}
		});
		downloadDialog.setNegativeButton(buttonNo, new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialogInterface, int i) {
			}
		});
		return downloadDialog.show();
	}
}