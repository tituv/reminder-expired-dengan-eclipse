package com.dummies.android.taskreminder;

import java.util.ArrayList;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.chart.BarChart.Type;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Paint.Align;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import com.anggoro.android.expiredreminder.R;

public class MainActivity extends Activity implements OnClickListener{
	
	private ImageButton btnAdd, btnCek, btnList, btnGraph, btnHelp;
	private View mChart;
	private String[] mMonth = new String[] { "Jan", "Feb" , "Mar", "Apr", "Mei", "Jun",
							  "Jul", "Agu" , "Sep", "Okt", "Nov", "Des" };

	private List<Integer> income = new ArrayList<Integer>();
	private DbAdapter mDbHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reminder_main);
		
		btnAdd = (ImageButton)findViewById(R.id.btn_add);
		btnCek = (ImageButton)findViewById(R.id.btn_cek);
		btnList = (ImageButton)findViewById(R.id.btn_list);
		btnGraph = (ImageButton)findViewById(R.id.btn_graph);
		btnHelp = (ImageButton)findViewById(R.id.btn_help);
		
		mDbHelper = new DbAdapter(this);
		
		btnAdd.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, EditActivity.class);
				startActivity(i);
				
			}
		});
		
		btnCek.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, CekActivity.class);
				startActivity(i);				
			}
		});
		
		btnList.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, ReminderListActivity.class);
				startActivity(i);				
			}
		});
		
		btnGraph.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, GraphActivity.class);
				startActivity(i);
			}
		});
		
		btnHelp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, HelpActivity.class);
				startActivity(i);
			}
		});
	}
	
	@Override
	public void onClick(View v) {
		/*switch (v.getId()) {
		case R.id.btn_add:
			startActivity(new Intent(ReminderMainActivity.this, ReminderEditActivity.class));
			break;
		case R.id.btn_cek:
			startActivity(new Intent(ReminderMainActivity.this, ReminderCekActivity.class));
			break;
		case R.id.btn_list:
			startActivity(new Intent(ReminderMainActivity.this, ReminderListActivity.class));
			break;
		case R.id.btn_graph:
			startActivity(new Intent(ReminderMainActivity.this, ReminderGraphActivity.class));
			break;
		}*/
	}

}
