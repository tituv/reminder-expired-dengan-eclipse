package com.dummies.android.taskreminder;

import com.anggoro.android.expiredreminder.R;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

public class EditActivity extends Activity implements OnClickListener {

	private static final int DATE_PICKER_DIALOG = 0;
	private static final int TIME_PICKER_DIALOG = 1;

	private static final String DATE_FORMAT = "yyyy-MM-dd";
	private static final String TIME_FORMAT = "kk:mm";
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd kk:mm:ss";

	private EditText mTitleText;
	private EditText mBodyText;

	private Button mDateButton;
	private Button mTimeButton;
	private Button mConfirmButton;
	private Button scanBtn;

	private Long mRowId;
	private DbAdapter mDbHelper;
	private Calendar mCalendar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reminder_edit);

		mDbHelper = new DbAdapter(this);
		mCalendar = Calendar.getInstance();
		mTitleText = (EditText) findViewById(R.id.name);
		mBodyText = (EditText) findViewById(R.id.code);
		mDateButton = (Button) findViewById(R.id.reminder_date);
		mTimeButton = (Button) findViewById(R.id.reminder_time);
		mConfirmButton = (Button) findViewById(R.id.confirm);
		scanBtn = (Button) findViewById(R.id.scan_button);
		scanBtn.setOnClickListener(this);

		mRowId = getIntent().getLongExtra(DbAdapter.KEY_ROWID, 0);
		mRowId = (mRowId != 0) ? mRowId : null;

		registerButtonListenersAndSetDefaultText();
	}

	@Override
	public void onClick(View v) {//click button scan
		if (v.getId() == R.id.scan_button) {
			IntentIntegrator scanIntegrator = new IntentIntegrator(this);
			scanIntegrator.initiateScan();
		}
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
		IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
		if (scanningResult != null) {
			String scanContent = scanningResult.getContents();
			String scanFormat = scanningResult.getFormatName();

			mDbHelper.open();
			Cursor c = mDbHelper.select(scanFormat + scanContent);

			if (c.getCount() != 0) {
				Toast.makeText(this, "Barcode sudah ada di database!", Toast.LENGTH_SHORT).show();
			} else {
				mBodyText.setText(scanFormat + scanContent);
			}
		} else {
			Toast toast = Toast.makeText(getApplicationContext(), "Data scan tidak ditemukan!", Toast.LENGTH_SHORT);
			toast.show();
		}
	}

	private void setRowIdFromIntent() {
		if (mRowId == null) {
			Bundle extras = getIntent().getExtras();
			mRowId = extras != null ? extras.getLong(DbAdapter.KEY_ROWID) : null;
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		mDbHelper.close();
	}

	@Override
	protected void onResume() {
		super.onResume();
		mDbHelper.open();
		setRowIdFromIntent();
		populateFields();
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DATE_PICKER_DIALOG:
			return showDatePicker();
		case TIME_PICKER_DIALOG:
			return showTimePicker();
		}
		return super.onCreateDialog(id);
	}

	private DatePickerDialog showDatePicker() {
		DatePickerDialog datePicker = new DatePickerDialog(EditActivity.this,
				new DatePickerDialog.OnDateSetListener() {

					@Override
					public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
						mCalendar.set(Calendar.YEAR, year);
						mCalendar.set(Calendar.MONTH, monthOfYear);
						mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

						// Subtract 6 days from Calendar updated date
//						mCalendar.add(Calendar.DATE, 0);

						// Set the Calendar new date as minimum date of date
						// picker

						updateDateButtonText();
					}
				}, mCalendar.get(Calendar.YEAR), mCalendar.get(Calendar.MONTH), mCalendar.get(Calendar.DAY_OF_MONTH));

		datePicker.getDatePicker().setMinDate(
				Calendar.getInstance().getTimeInMillis() - 1000);
		return datePicker;
	}

	private TimePickerDialog showTimePicker() {
		TimePickerDialog timePicker = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {

					@Override
					public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
						mCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
						mCalendar.set(Calendar.MINUTE, minute);
						mCalendar.set(Calendar.SECOND, 0);
						updateTimeButtonText();
					}
				}, mCalendar.get(Calendar.HOUR_OF_DAY),	mCalendar.get(Calendar.MINUTE), true);

		return timePicker;
	}

	private void populateFields() {

		if (mRowId != null) {
			Cursor reminder = mDbHelper.fetchReminder(mRowId);
			reminder.moveToFirst();
			mTitleText.setText(reminder.getString(reminder.getColumnIndexOrThrow(DbAdapter.KEY_TITLE)));
			mBodyText.setText(reminder.getString(reminder.getColumnIndexOrThrow(DbAdapter.KEY_BODY)));

			SimpleDateFormat dateTimeFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
			Date date = null;
			try {
				String dateString = reminder.getString(reminder.getColumnIndexOrThrow(DbAdapter.KEY_DATE_TIME));
				date = dateTimeFormat.parse(dateString);
				mCalendar.setTime(date);
			} catch (ParseException e) {
				Log.e("ReminderEditActivity", e.getMessage(), e);
			}
		} else {
			SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
			String defaultTitleKey = getString(R.string.pref_task_title_key);
			String defaultTimeKey = getString(R.string.pref_default_time_from_now_key);

			String defaultTitle = prefs.getString(defaultTitleKey, null);
			String defaultTime = prefs.getString(defaultTimeKey, null);

			if (defaultTitle != null)
				mTitleText.setText(defaultTitle);

			if (defaultTime != null)
				mCalendar.add(Calendar.MINUTE, Integer.parseInt(defaultTime));
		}
		updateDateButtonText();
		updateTimeButtonText();
	}

	private void updateTimeButtonText() {
		SimpleDateFormat timeFormat = new SimpleDateFormat(TIME_FORMAT);
		String timeForButton = timeFormat.format(mCalendar.getTime());
		mTimeButton.setText(timeForButton);
	}

	private void updateDateButtonText() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		String dateForButton = dateFormat.format(mCalendar.getTime());
		mDateButton.setText(dateForButton);
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		// outState.putLong(RemindersDbAdapter.KEY_ROWID, mRowId);
	}
	
	private void registerButtonListenersAndSetDefaultText() {
		mDateButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				showDialog(DATE_PICKER_DIALOG);
			}
		});

		mTimeButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				showDialog(TIME_PICKER_DIALOG);
			}
		});

		mConfirmButton.setOnClickListener(new View.OnClickListener() {
			@SuppressLint("NewApi")
			@Override
			public void onClick(View view) {

				if (mTitleText.getText().toString().isEmpty()) {
					Toast.makeText(getApplicationContext(), "Silakan lengkapi data produk!", Toast.LENGTH_SHORT).show();
				} else if (mBodyText.getText().toString().isEmpty()) {
					Toast.makeText(getApplicationContext(), "Silakan lengkapi data produk!", Toast.LENGTH_SHORT).show();
				} else {
					saveState();
					setResult(RESULT_OK);
					Toast.makeText(EditActivity.this, getString(R.string.task_saved_message), Toast.LENGTH_SHORT).show();
					finish();
				}
			}
		});
		updateDateButtonText();
		updateTimeButtonText();
	}

	private void saveState() {
		String title = mTitleText.getText().toString();
		String body = mBodyText.getText().toString();

		SimpleDateFormat dateTimeFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
		String reminderDateTime = dateTimeFormat.format(mCalendar.getTime());
		// Log.d("MONTH", reminderDateTime);

		if (mRowId == null) {
			String month = reminderDateTime.substring(5, 7);
			// Log.i("MONTH", month);
			long id = mDbHelper.createReminder(title, body, reminderDateTime, month);
			if (id > 0) {
				mRowId = id;
			}
		} else {
			String month = reminderDateTime.substring(1, 4);
			// Log.i("MONTH", month);
			mDbHelper.updateReminder(mRowId, title, body, reminderDateTime,	month);
		}
		new ReminderManager(this).setReminder(mRowId, mCalendar);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater mi = getMenuInflater();
		mi.inflate(R.menu.edit_menu, menu);
		return true;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menu_list:
			list();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	private void list() {
		Intent i = new Intent(EditActivity.this, ReminderListActivity.class);
		startActivity(i);
	}
}