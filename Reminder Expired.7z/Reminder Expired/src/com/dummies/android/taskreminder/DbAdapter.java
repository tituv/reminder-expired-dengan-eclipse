package com.dummies.android.taskreminder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
import android.widget.Toast;

public class DbAdapter {

	private static final String DATABASE_NAME = "data";// database name
	private static final String DATABASE_TABLE = "reminders";// table name
	private static final int DATABASE_VERSION = 3;

	public static final String KEY_TITLE = "name"; // name product
	public static final String KEY_BODY = "barcode"; // barcode
	public static final String KEY_DATE_TIME = "reminder_date_time";// date time
	public static final String KEY_MONTH = "reminder_month";// month
	public static final String KEY_ROWID = "_id";// id data

	private static final String TAG = "ReminderDbAdapter";
	private DatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	private static final String DATABASE_CREATE = "create table "
			+ DATABASE_TABLE + " (" + KEY_ROWID
			+ " integer primary key autoincrement, " + KEY_TITLE
			+ " text not null, " + KEY_BODY + " text not null, "
			+ KEY_DATE_TIME + " text not null, " + KEY_MONTH + " text )";// query
																			// create
																			// table
																			// in
																			// database

	private final Context mCtx;

	private static class DatabaseHelper extends SQLiteOpenHelper {

		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);// use
																	// database
																	// helper
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);// execute create
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {// upgrade
																					// database
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}
	}

	public DbAdapter(Context ctx) {// contructor from dbAdapter
		this.mCtx = ctx;
	}

	public DbAdapter open() throws SQLException {// open conection database
		mDbHelper = new DatabaseHelper(mCtx);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	public void close() {// close conection database
		mDbHelper.close();
	}

	public long createReminder(String title, String body,
			String reminderDateTime, String month) {// create data reminder with
													// parameter
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_TITLE, title);// name
		initialValues.put(KEY_BODY, body);// barcode
		initialValues.put(KEY_DATE_TIME, reminderDateTime);// date time
		initialValues.put(KEY_MONTH, month);// month

		return mDb.insert(DATABASE_TABLE, null, initialValues);// execute insert
																// data to table
	}

	public boolean deleteReminder(long rowId) {// delete reminder with same id
		return mDb.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
	}

	public Cursor fetchAllReminders() {
		return mDb.query(DATABASE_TABLE, new String[] { KEY_ROWID, KEY_TITLE,
				KEY_BODY, KEY_DATE_TIME }, null, null, null, null, null);
	}

	public Cursor fectByMonth(String month) {// show data from spinner in month
		String sql = "SELECT * FROM " + DATABASE_TABLE + " WHERE " + KEY_MONTH
				+ "='" + month + "'";
		return mDb.rawQuery(sql, null);
	}

	public Cursor getAllProduk() {// show all data product
		String sql = "SELECT * FROM " + DATABASE_TABLE;
		return mDb.rawQuery(sql, null);
	}

	public Cursor fetchReminder(long rowId) throws SQLException {
		String sql = "SELECT * FROM " + DATABASE_TABLE + " WHERE " + KEY_ROWID
				+ "=" + rowId;
		Log.i("Execution", "SQL=" + sql);
		return mDb.rawQuery(sql, null);
	}

	public boolean updateReminder(long rowId, String title, String body,
			String reminderDateTime, String month) {
		ContentValues args = new ContentValues();
		args.put(KEY_TITLE, title);// put name
		args.put(KEY_BODY, body);// put barcode
		args.put(KEY_DATE_TIME, reminderDateTime);// put date time
		args.put(KEY_MONTH, month);// month

		return mDb.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId, null) > 0;
	}

	public Cursor select(String body) {// show data if barcode same with data
		String sql = "SELECT * FROM " + DATABASE_TABLE + " WHERE " + KEY_BODY
				+ "='" + body + "'";
		return mDb.rawQuery(sql, null);
	}

	public int selectbymonth(String month) {// show data with same month
		int sum = 0;
		String sql = "SELECT * FROM " + DATABASE_TABLE + " WHERE " + KEY_MONTH
				+ "='" + month + "'";

		Cursor c = mDb.rawQuery(sql, null);
		long l = c.getCount();
		sum = (int) (long) l;
		return sum;
	}

	public Cursor selectSpinner(String month) {
		String sql = "SELECT * FROM " + DATABASE_TABLE + " WHERE " + KEY_MONTH
				+ "='" + month + "'";
		return mDb.rawQuery(sql, null);
	}

	public Cursor selectByTanggal(String bulan, String tahun) {
		String sql = "SELECT * FROM " + DATABASE_TABLE
				+ " WHERE strftime('%m'," + KEY_DATE_TIME + ")='" + bulan
				+ "' AND strftime('%Y'," + KEY_DATE_TIME + ")='" + tahun + "'";
		// Toast.makeText(mCtx, sql, Toast.LENGTH_LONG).show();
		return mDb.rawQuery(sql, null);
	}

	public int selectGrafik(String bulan, String tahun) {
		int sum = 0;
		String sql = "SELECT * FROM " + DATABASE_TABLE
				+ " WHERE strftime('%m'," + KEY_DATE_TIME + ")='" + bulan
				+ "' AND strftime('%Y'," + KEY_DATE_TIME + ")='" + tahun + "'";
		
		Cursor c = mDb.rawQuery(sql, null);
		long l = c.getCount();
		sum = (int) (long) l;
		return sum;
	}
}