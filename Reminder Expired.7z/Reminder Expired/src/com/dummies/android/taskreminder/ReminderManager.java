package com.dummies.android.taskreminder;

import java.util.Calendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public class ReminderManager {

	private Context mContext;
	private AlarmManager mAlarmManager;

	public ReminderManager(Context context) {
		mContext = context;
		mAlarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
	}

	public void setReminder(Long taskId, Calendar when) {
		Intent i = new Intent(mContext, OnAlarmReceiver.class);
		i.putExtra(DbAdapter.KEY_ROWID, (long) taskId);

		PendingIntent pi = PendingIntent.getBroadcast(mContext,	(int) (long) taskId, i, 0);

		mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
				(when.getTimeInMillis() - (7 * AlarmManager.INTERVAL_DAY)),	AlarmManager.INTERVAL_DAY, pi);//set 7 day for reminder wakeup
	}

	public void cancelReminder() {
		Intent i = new Intent(mContext, OnAlarmReceiver.class);
		PendingIntent sender = PendingIntent.getBroadcast(mContext, 0, i, 0);
		mAlarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
		mAlarmManager.cancel(sender);
	}
}