package com.dummies.android.taskreminder;

import java.util.ArrayList;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.chart.BarChart.Type;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Paint.Align;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

import com.anggoro.android.expiredreminder.R;

public class GraphActivity extends Activity {

	private View mChart;
	private String[] mMonth = new String[] { "Jan", "Feb", "Mar", "Apr", "Mei",
			"Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des" };

	private List<Integer> income = new ArrayList<Integer>();
	private DbAdapter mDbHelper;

	private Spinner spinner;
	private static final String[] years = { "2016", "2017", "2018", "2019",
			"2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reminder_graph);
		mDbHelper = new DbAdapter(this);

		spinner = (Spinner) findViewById(R.id.spinner1);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(
				GraphActivity.this, android.R.layout.simple_spinner_item, years);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(adapter);

		spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				openChart();
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
			}
		});
	}

	private void openChart() {
		getJumlahKadaluwarsa();

		// bulan
		int[] x = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };

		// Creating an XYSeries for Income
		XYSeries incomeSeries = new XYSeries("Jumlah produk Kadaluarsa");
		for (int i = 0; i < x.length; i++) {
			incomeSeries.add(i, income.get(i));
		}

		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		dataset.addSeries(incomeSeries);

		XYSeriesRenderer incomeRenderer = new XYSeriesRenderer();
		incomeRenderer.setColor(Color.BLACK);
		incomeRenderer.setFillPoints(true);
		incomeRenderer.setLineWidth(2);
		incomeRenderer.setDisplayChartValues(true);
		XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
		multiRenderer
				.setOrientation(XYMultipleSeriesRenderer.Orientation.HORIZONTAL);
		multiRenderer.setXLabels(0);
		multiRenderer.setChartTitle("Data Produk Kadaluarsa");
		multiRenderer.setXTitle("Bulan");
		multiRenderer.setYTitle("Jumlah produk (Pcs)");

		// Customizing graphs
		// setting text size of the title
		multiRenderer.setChartTitleTextSize(35);
		// setting text size of the axis title
		multiRenderer.setAxisTitleTextSize(24);
		// setting text size of the graph lable
		multiRenderer.setLabelsTextSize(24);
		// setting zoom buttons visiblity
		multiRenderer.setZoomButtonsVisible(false);
		// setting pan enablity which uses graph to move on both axis
		multiRenderer.setPanEnabled(true, true);
		// setting click false on graph
		multiRenderer.setClickEnabled(false);
		// setting zoom to false on both axis
		multiRenderer.setZoomEnabled(true, true);
		// setting lines to display on y axis
		multiRenderer.setShowGridY(true);
		// setting lines to display on x axis
		multiRenderer.setShowGridX(true);
		// setting legend to fit the screen size
		multiRenderer.setFitLegend(true);
		// setting displaying line on grid
		multiRenderer.setShowGrid(true);
		// setting zoom to false
		multiRenderer.setZoomEnabled(true);
		// setting external zoom functions to false
		multiRenderer.setExternalZoomEnabled(true);
		// setting displaying lines on graph to be formatted(like using
		// graphics)
		multiRenderer.setAntialiasing(true);
		// setting to in scroll to false
		multiRenderer.setInScroll(true);
		// setting to set legend height of the graph
		multiRenderer.setLegendHeight(60);
		// setting x axis label align
		multiRenderer.setXLabelsAlign(Align.CENTER);
		// setting y axis label to align
		multiRenderer.setYLabelsAlign(Align.LEFT);
		// setting text style
		multiRenderer.setTextTypeface("sans_serif", Typeface.NORMAL);
		// setting no of values to display in y axis
		multiRenderer.setYLabels(10);
		// setting y axis max value
		multiRenderer.setYAxisMax(50);
		// setting used to move the graph on xaxiz to .5 to the right
		multiRenderer.setXAxisMin(-1);
		// setting max values to be display in x axis
		multiRenderer.setXAxisMax(11);
		// setting bar size or space between two bars
		multiRenderer.setBarSpacing(0.5);
		// Setting background color of the graph to transparent
		multiRenderer.setBackgroundColor(Color.TRANSPARENT);
		// Setting margin color of the graph to transparent
		multiRenderer.setMarginsColor(getResources().getColor(
				R.color.transparent_background));
		multiRenderer.setApplyBackgroundColor(true);
		// setting the margin size for the graph in the order top, left, bottom,
		// right
		multiRenderer.setMargins(new int[] { 30, 30, 30, 30 });

		for (int i = 0; i < x.length; i++) {
			multiRenderer.addXTextLabel(i, mMonth[i]);
		}

		multiRenderer.addSeriesRenderer(incomeRenderer);

		// this part is used to display graph on the xml
		LinearLayout chartContainer = (LinearLayout) findViewById(R.id.chart);
		// remove any views before u paint the chart
		chartContainer.removeAllViews();
		// drawing bar chart
		mChart = ChartFactory.getBarChartView(GraphActivity.this, dataset,
				multiRenderer, Type.DEFAULT);
		// adding the view to the linearlayout
		chartContainer.addView(mChart);
	}

	public void getJumlahKadaluwarsa() {
		income.clear();
		String[] m = { "01", "02", "03", "04", "05", "06", "07", "08", "09",
				"10", "11", "12" };

		String tahun = String.valueOf(spinner.getSelectedItemPosition() + 2016);

		for (int a = 0; a < m.length; a++) {
			int sum = 30;
			mDbHelper = new DbAdapter(this);
			mDbHelper.open();
			// sum = mDbHelper.selectbymonth(m[a]);
			sum = mDbHelper.selectGrafik(m[a], tahun);
			income.add(sum);
		}
	}
}